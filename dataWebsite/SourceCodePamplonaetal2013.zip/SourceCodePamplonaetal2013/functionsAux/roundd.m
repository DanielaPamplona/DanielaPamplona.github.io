function n = roundd(x)
n = round(x-10^(-4));


%intdiv(x,1)