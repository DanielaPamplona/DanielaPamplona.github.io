function deg_matrix =  rad2deg(rad_matrix)
%convert radians to degrees
    deg_matrix = rad_matrix*360/(2*pi);
