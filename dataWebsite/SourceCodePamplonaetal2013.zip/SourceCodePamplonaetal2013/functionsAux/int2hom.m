function [x,y] = int2hom(x1, y1)
%change the coordinates of a point in intrinsic  to  homogeneous
y = -y1;
x = x1;
