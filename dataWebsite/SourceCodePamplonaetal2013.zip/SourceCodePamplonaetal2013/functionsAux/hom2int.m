function [x1,y1] = hom2int(x, y)
%change the coordinates of a point in homogeneous to intrinsic


y1 = -y;
x1 = x;
