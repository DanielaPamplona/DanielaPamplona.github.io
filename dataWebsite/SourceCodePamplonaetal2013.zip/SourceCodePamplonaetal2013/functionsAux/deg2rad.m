function rad_matrix =  deg2rad(deg_matrix)
%transform angles in degrees into radians
    rad_matrix = deg_matrix*2*pi/360;
